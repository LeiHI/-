<html>
<head>
<meta charset="utf-8"> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DeleteTerm</title>
<style type="text/css">
table, td, th
{
	border:1px solid green;
	text-align:center;
	padding:15px;
	
	
	margin:auto;
}
body{
    background-color:#F0FFF0;
}
</style>
</head>
<body>
<input type="button" value="返回主页" onclick="window.location='main.html';" 
style="width:90px; font-size:20px; border-color:yellow; background-color:gold"/>
<div style="font-size:48px; text-align:center;font-family:'楷体'">删除术语</div>
<br/>
<form action="deletere.php" method="post">
<?php

$dbhost = 'localhost';  //mysql服务器主机地址
   $dbuser = 'root';      //mysql用户名
   $dbpass = '';//mysql用户名密码
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   if(! $conn )
   {
     die('Could not connect: ' . mysqli_error());
   }

   mysqli_select_db( $conn,"stiterm" );
   mysqli_query($conn,"set names 'utf8'");

$sql="select * from tmdata";

$cunt=0;
   $huoqu = mysqli_query($conn, $sql);
   $num = mysqli_num_rows($huoqu);
   
    echo "<table border='1' align='center'>
          	<tr>
                <th>种类</th>
                <th>类型</th>
                <th>中文</th>
	 	<th>英文</th>
	 	<th width='50pt'>选择</th></tr>";
    while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)) {  
            echo "<tr>";
	    echo "<td width='60pt' align='center'>"."术语"."</td>";
	    echo "<td width='200pt' align='center'>".$row['type']."</td>";
            echo "<td width='200pt' align='center'>".$row['zh_CN']."</td>";
            echo "<td width='200pt' align='center'>".$row['en_US']."</td>";
$cunt = $row['count'];
	if($cunt == 1001){
	echo "<td align='center'><input type='radio' name='Submit' value='$cunt' checked='checked'/>";
	}
	else{
	echo "<td align='center'><input type='radio' name='Submit' value='$cunt'/></td>";}
        echo "</tr>";
	}
	$sql="select * from tmxdata";
	$huoqu = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)) {  
            echo "<tr>";
	    echo "<td width='60pt' align='center'>"."语料库"."</td>";
	    echo "<td width='200pt' align='center'>".$row['type']."</td>";
            echo "<td width='200pt' align='center'>".$row['zh_CN']."</td>";
            echo "<td width='200pt' align='center'>".$row['en_US']."</td>";
		$cunt = $row['count'];
	echo "<td align='center'><input type='radio' name='Submit' value='$cunt'/></td>";
            }  
        echo "</tr>";
    echo "</table>\n"; 
   mysqli_close($conn);

?>
</br>
</br>
<button type="submit" name="but" value=”Delete" style="width:135px; font-size:16px;float:right;"/>删除</button>
</form>
</body>
</html>