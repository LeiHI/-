<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TermAdding</title>
<style type="text/css">
th{width:150;align:center}
td{text-align:center}
#first{width:470; align:center; height:60; text-align:center}

body
{
	background-color:#F0FFF0;
}
</style>
</head>
<body>
<input type="button" value="返回主页" onclick="window.location='main.html';" style="width:90px; font-size:20px; border-color:yellow; background-color:gold"/>
</br>
</br>
</br>
<input type="button" value="返回增加术语" onclick="window.location='add.php';" style="width:135px; font-size:20px; border-color:yellow; background-color:gold"/>
</br>
</br>
</br>
<?php
   $dbhost = 'localhost:3306';  //mysql服务器主机地址
   $dbuser = 'root';      //mysql用户名
   $dbpass = '';//mysql用户名密码
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   if(! $conn )
   {
     die('Could not connect: ' . mysqli_error());
   }
   
$type = $_POST['types'];
$zh = $_POST['zh'];
$en = $_POST['en'];
$TTM = $_POST['TTM'];
$NTP = "Apple";
if($_POST['types'] == '其他'){
	if($_POST['Adding'] != NULL){
		$NTP = $_POST['Adding'];
	};
}
else{
	$NTP = $_POST['types'];
}

mysqli_select_db( $conn,"stiterm" );
mysqli_query($conn,"set names 'utf8'");
if($TTM == "Term"){
	$sql = "INSERT INTO tmdata (zh_CN, en_US, type) VALUES ('$zh','$en','$NTP')";
}
else{
	$sql = "INSERT INTO tmxdata (zh_CN, en_US, type) VALUES ('$zh','$en','$NTP')";
}

if ($conn->query($sql) == TRUE) {
    echo "<div style='font-family:'楷体';font-size:x-large;color:#F4A460'>新记录插入成功!</div>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$sql = "if not exists (INSERT INTO typedata (type) VALUES ('$NTP'))";
$conn->query($sql);
$sql = "SELECT * FROM typedata";
$huoqu = mysqli_query($conn, $sql);
$lp = 1;
while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)){
	$_CN = $row['type'];
	$sq = "UPDATE typedata SET count = '$lp' WHERE type LIKE '$_CN'";
	mysqli_query($conn, $sq);
	$lp = $lp+1;
}
$sq = "UPDATE typedata SET count = '$lp' WHERE type LIKE '其他'";
mysqli_query($conn, $sq);



if($TTM == "Term"){
	$sql = "SELECT * FROM tmdata";
	$huoqu = mysqli_query($conn, $sql);
	$lp = 1001;
	while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)){
		$_CN = $row['zh_CN'];
		$sq = "UPDATE tmdata SET count = '$lp' WHERE zh_CN LIKE '$_CN'";
		mysqli_query($conn, $sq);
		$lp = $lp+1;
	}
}
else{
	$sql = "SELECT * FROM tmxdata";
	$huoqu = mysqli_query($conn, $sql);
	$lp = 2001;
	while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)){
		$_CN = $row['zh_CN'];
		$sq = "UPDATE tmxdata SET count = '$lp' WHERE zh_CN LIKE '$_CN'";
		mysqli_query($conn, $sq);
		$lp = $lp+1;
	}
}


mysqli_close($conn);
?>
</body>
</html>