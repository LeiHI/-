<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TermEditing</title>
<style type="text/css">
th{width:150;align:center}
td{text-align:center}
#first{width:470; align:center; height:60; text-align:center}
body{
    background-color:#F0FFF0;
}
</style>
</head>
<body>
<input type="button" value="返回主页" onclick="window.location='main.html';" style="width:90px; font-size:20px; border-color:yellow; background-color:gold"/>
<input type="button" value="返回术语修改" onclick="window.location='edit.php';" style="width:135px; font-size:20px; border-color:yellow; background-color:gold"/>
<form action="jump.php" method="post">
<?php
   $dbhost = 'localhost:3306';  //mysql服务器主机地址
   $dbuser = 'root';      //mysql用户名
   $dbpass = '';//mysql用户名密码
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   if(! $conn )
   {
     die('Could not connect: ' . mysqli_error());
   }


$no= $_POST['Submit'];
if(($no>=1000)&&($no<=1999)){
$sql = "select * from tmdata where count like '$no'";}
else{
  $sql = "select * from tmxdata where count like '$no'";
}

   mysqli_select_db( $conn,"stiterm" );
   mysqli_query($conn,"set names 'utf8'");

   $huoqu = mysqli_query($conn, $sql);
   $num = mysqli_num_rows($huoqu);

    while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)) {
echo '<br/>以下为要修改的词<br/>中文：'.$row['zh_CN'].'<br/>英语：'.$row['en_US'];
echo '<br/></br>请修改你想变动的地方<br/></br>编号为：';
echo "<input type='text' name='no' value='$no' readonly='readonly'/>";
echo '<br/></br>中文：';
$CN = $row['zh_CN'];
echo "<textarea row='4' cols='40' name='chinese'>$CN</textarea>";
echo '<br/></br>英语：';
$EN = $row['en_US'];
echo "<textarea row='4' cols='40' name='english'>$EN</textarea>";
echo '<br/></br>*如不需要修改请不要做任何变动<br/>';
echo "<span name='no' value='$no'/>";
}
   mysqli_close($conn);
?>
<button type="submit" name="but" value='Confirm' style="width:135px; font-size:16px;"/>确认修改</button>
</form>

</body>
</html>
