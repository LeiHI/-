<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DeleteTerm</title>
<style type="text/css">
th{width:150;align:center}
td{text-align:center}
#first{width:470; align:center; height:60; text-align:center}

table, td, th
{
	border:1px solid green;
	text-align:center;
	padding:15px;
	
	
	margin:auto;
}
body{
    background-color:#F0FFF0;
}
</style>
</head>
<body>
<input type="button" value="返回主页" onclick="window.location='main.html';"
 style="width:90px; font-size:20px; border-color:yellow; background-color:gold"/>

<input type="button" value="返回术语删除" onclick="window.location='delete.php';" 
style="width:135px; font-size:20px; border-color:yellow; background-color:gold"/>
<?php
   $dbhost = 'localhost';  //mysql服务器主机地址
   $dbuser = 'root';      //mysql用户名
   $dbpass = '';//mysql用户名密码
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   if(! $conn )
   {
     die('Could not connect: ' . mysqli_error());
   }

$no = $_POST['Submit'];

mysqli_select_db( $conn,"stiterm" );
mysqli_query($conn,"set names 'utf8'");
if(($no>=1000)&&($no<=1999)){
	$sql = "SELECT * FROM tmdata WHERE count LIKE '$no'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0){
		mysqli_query($conn,"DELETE FROM tmdata WHERE count LIKE '$no'");}
}
else{
	$result = $conn->query($sql);
	if ($result->num_rows > 0){
		mysqli_query($conn,"DELETE FROM tmxdata WHERE count LIKE '$no'");}

}
echo '<br/><h3>删除成功!</h3>';

$sql = "SELECT * FROM tmdata";
$huoqu = mysqli_query($conn, $sql);
$lp = 1001;
while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)){
	$_CN = $row['zh_CN'];
	$sq = "UPDATE tmdata SET count = '$lp' WHERE zh_CN LIKE '$_CN'";
	mysqli_query($conn, $sq);
	$lp = $lp+1;
}
mysqli_close($conn);
?>
</body>
</html>
