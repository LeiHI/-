<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>STIDATA</title>
<style type="text/css">
th{width:150;align:center}
td{text-align:center}
#first{width:470; align:center; height:60; text-align:center}
</style>
</head>
<body>
<input type="button" value="返回" onclick="window.location='index.html';" style="width:80px; font-size:20px; border-color:yellow; background-color:gold"/>
<?php
   $dbhost = 'localhost:3306';  //mysql服务器主机地址
   $dbuser = 'root';      //mysql用户名
   $dbpass = '';//mysql用户名密码
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   if(! $conn )
   {
     die('Could not connect: ' . mysqli_error());
   }
   


$nam=$_POST['user'];
$pas=$_POST['password'];

mysqli_select_db( $conn,"stiterm" );
mysqli_query($conn,"set names 'utf8'");

$sql = 'unknow';
$sql = "SELECT * FROM userdata WHERE user = '$nam'";
$huoqu = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)) {
	if($pas == $row['password']){
		header("Location: main.html"); 
	}
}
echo 'username or password incorrect';
mysqli_close($conn);
?>
</body>
</html>