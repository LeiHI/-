<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SearchTerm</title>
<style type="text/css">
th{width:150;align:center}
td{text-align:center}
#first{width:470; align:center; height:60; text-align:center}

table, td, th
{
	border:1px solid green;
	text-align:center;
	padding:15px;


	margin:auto;
}
body{
    background-color:#F0FFF0;
}


</style>
</head>
<body>
<input type="button" value="返回主页" onclick="window.location='main.html';" style="width:90px; font-size:20px; border-color:yellow; background-color:gold"/>
<input type="button" value="返回术语查询" onclick="window.location='search.php';" style="width:135px; font-size:20px; border-color:yellow; background-color:gold"/>
<?php
   $dbhost = 'localhost';  //mysql服务器主机地址
   $dbuser = 'root';      //mysql用户名
   $dbpass = '';//mysql用户名密码
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   if(! $conn )
   {
     die('Could not connect: ' . mysqli_error());
   }

if($_POST['chbox']=='no'){
	$chbox = 'off';
}
else{
	$chbox = 'on';
}

$type = $_POST['types'];
$TTM = $_POST['TTM'];
$sql1 = "apple";

mysqli_select_db( $conn,"stiterm" );
mysqli_query($conn,"set names 'utf8'");
$searchterm =$_POST['searchterm'];

if($chbox=='on'){
	if($TTM=='ALL'){
   	$sql = "SELECT * FROM tmdata WHERE zh_CN REGEXP '$searchterm.*' or en_US REGEXP '$searchterm.*'";
		$sql1 = "SELECT * FROM tmxdata WHERE zh_CN REGEXP '$searchterm.*' or en_US REGEXP '$searchterm.*'";
		$TTM = "TERM";
	}
	elseif($TTM=='Term'){
		$sql = "SELECT * FROM tmdata WHERE zh_CN REGEXP '$searchterm.*' or en_US REGEXP '$searchterm.*'";
		$TTM = "TERM";
	}
	else{
		$sql = "SELECT * FROM tmxdata WHERE zh_CN REGEXP '$searchterm.*' or en_US REGEXP '$searchterm.*'";
		$TTM = "TMX";
	}
}
else{
	if($TTM=='ALL'){
   	$sql = "SELECT * FROM tmdata WHERE zh_CN LIKE '$searchterm' or en_US LIKE '$searchterm'";
		$sql1 = "SELECT * FROM tmxdata WHERE zh_CN LIKE '$searchterm.*' or en_US LIKE '$searchterm.*'";
		$TTM = "TERM";
	}
	elseif($TTM=='Term'){
		$sql = "SELECT * FROM tmdata WHERE zh_CN LIKE '$searchterm.*' or en_US LIKE '$searchterm.*'";
		$TTM = "TERM";
	}
	else{
		$sql = "SELECT * FROM tmxdata WHERE zh_CN LIKE '$searchterm.*' or en_US LIKE '$searchterm.*'";
		$TTM = "TMX";
	}
}

$huoqu = mysqli_query($conn, $sql);
$num = mysqli_num_rows($huoqu);
if($sql1!="apple"){
	$huoqu1 = mysqli_query($conn, $sql1);
	$num += mysqli_num_rows($huoqu1);
}

        print '<table border=1; id="first"; align="center">';
        print '<tr>
	<td>
	<h3>您输入了字符"'.$searchterm.'"<br/>模糊搜索为"'.$chbox.'"<br/>搜索类型为"'.$type.'"<br/>共计'.$num.'条数据</h3>
	</td>
	</tr>';
        print '</table>';
    echo "</br></br>";
    echo "<table border='1'; align='center' >
                <th>种类</th>
                <th>类型</th>
                <th>中文</th>
	 	<th>英文</th>
                </tr>";
    while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)) {
           	 echo "<tr>";
           	 echo "<td>".$TTM."</td>";
	   	 echo "<td>".$row['type']."</td>";
           	 echo "<td>".$row['zh_CN']."</td>";
           	 echo "<td>".$row['en_US']."</td>";
            	echo "</tr>";
            }
if($sql1!="apple"){
	while ($row = mysqli_fetch_array($huoqu1, MYSQLI_ASSOC)) {
         	echo "<tr>";
           	echo "<td>TMX</td>";
	   	echo "<td>".$row['type']."</td>";
           	echo "<td>".$row['zh_CN']."</td>";
		echo "<td>".$row['en_US']."</td>";
            	echo "</tr>";
	}

}
    echo "</table>\n";
   mysqli_close($conn);
?>
</body>
</html>
