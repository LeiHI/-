<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TermAdding</title>
<style type="text/css">
th{width:150;align:center}
td{text-align:center}
#first{width:470; align:center; height:60; text-align:center}
</style>
</head>
<body>
<?php
   $dbhost = 'localhost:3306';  //mysql服务器主机地址
   $dbuser = 'root';      //mysql用户名
   $dbpass = '';//mysql用户名密码
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   if(! $conn )
   {
     die('Could not connect: ' . mysqli_error());
   }

$no = $_POST['no'];
$zh = $_POST['chinese'];
$en = $_POST['english'];
echo $zh;
echo $no;

mysqli_select_db( $conn,"stiterm" );
mysqli_query($conn,"set names 'utf8'");
if(($no>=1000)&&($no<=1999)){
  $sql = "UPDATE tmdata SET zh_CN = '$zh' , en_US = '$en' WHERE count='$no'";
}
else{
  $sql = "UPDATE tmxdata SET zh_CN = '$zh' , en_US = '$en' WHERE count='$no'";
}

mysqli_query($conn, $sql);

mysqli_close($conn);
header("Location: edit.php");
?>
</body>
</html>
