<html>
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TermAdding</title>
<style type="text/css">
table, td, th
{
	border:1px solid green;
	text-align:center;
	width:50%;
	height:50%;

	margin:auto;
}
body{
    background-color:#F0FFF0;
}
</style>

<script type="text/javascript">

function showtext(){
	var val;
	val = document.getElementsByTagName("select")[0];
	var put=document.createElement("input");
	var sec=document.getElementById("p1");
	put.placeholder = "请输入新的类型";
	put.name = "Adding";
	put.id="temp"
	if(val.value == "其他"){
		sec.appendChild(put);
	};
	if(val.value != "其他"){
		put=document.getElementById("temp");
		sec.removeChild(put);
	};
}
</script>

</head>
<body>
<input type="button" value="返回主页" onclick="window.location='main.html';" style="width:90px; font-size:18px; border-color:##FFB7DD; background-color:gold;"/>
<div style="font-size:40px; text-align:center;font-family:'楷体'">添加术语</div>
<br/>
<form action="addre.php" method="post">
    <table border=1 title="SEARCH" align="center">
        <tr>
        <td width="300" height="100">
	<textarea rows="10" cols="50" name="zh" placeholder="请输入中文(不可多于200字符）"></textarea></td>
	<td rowspan="4"><button type="submit" name="but" value="Add" style="width:135px;height:50px;font-size:16px;color:#008800;"/>加 入</button></td>
	</tr>
	<tr>
	<td width="300">
	<textarea rows="10" cols="50" name="en" placeholder="请输入英语(不可多于200字符）"></textarea></td></tr>
	<tr><td width="300" id="p1">
	类型：
	<?php
	$dbhost = 'localhost:3306';  //mysql服务器主机地址
	$dbuser = 'root';      //mysql用户名
	$dbpass = '';//mysql用户名密码
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
	if(! $conn )
	{
		die('Could not connect: ' . mysqli_error());
	}
	mysqli_select_db( $conn,"stiterm" );
	mysqli_query($conn,"set names 'utf8'");
	$sql="select * from typedata";
	$huoqu = mysqli_query($conn, $sql);
	echo "<select name='types' onchange = 'showtext()'>";
	while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)) {
		if($row['type'] != '全部'){
		echo "<option value ='".$row['type']."'>".$row['type']."</option>";}
	}
	echo "</select>";
	?>

	</td></tr>
	<tr>
	<td>
	<input type="radio" name="TTM" value="Term" checked="checked"/>术语
	<input type="radio" name="TTM" value="TMX"/>翻译记忆
	</td>
	<tr/>
	</table>
</form>
</body>
</html>
