<html>
<head>
<meta charset="utf-8"> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SearchTerm</title>
<style type="text/css">
table, td, th
{
	border:1px solid green;
	text-align:center;
	width:50%;
	height:50%;
	
	margin:auto;
}
body{
    background-color:#F0FFF0;
}
</style>


</head>

<body>
<input type="button" value="返回主页" onclick="window.location='main.html';" style="width:95px; font-size:20px; border-color:yellow; background-color:gold"/>
<div style="font-size:40px; text-align:center;font-family:'楷体'">术语查询</div>
<br/>
<form action="searchre.php" method="post">
    <table border=1 title="SEARCH" align="center">
        <tr>
        <td width="300">
	<input type="text" name="searchterm" placeholder="请输入查询的术语" style="width:220;height:50;"/></td>
	<td><button type="submit" name="but" value="search" style="width:135px;height:45px;font-size:16px;color:#008800;"/>搜索</button></td></tr>

	<tr>
	
	<td colspan='2'>模糊搜索：<input type="radio" name="chbox" value="yes"/>是&nbsp;&nbsp;&nbsp;
	<input type="radio" name="chbox" value="no" checked="checked"/>否</td>
	</tr>
	<tr>
	<td colspan='2' id="p1" >类型：
	<?php
	$dbhost = 'localhost:3306';  //mysql服务器主机地址
	$dbuser = 'root';      //mysql用户名
	$dbpass = '';//mysql用户名密码
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
	if(! $conn )
	{
		die('Could not connect: ' . mysqli_error());
	}
	mysqli_select_db( $conn,"stiterm" );
	mysqli_query($conn,"set names 'utf8'");
	$sql="select * from typedata";
	$huoqu = mysqli_query($conn, $sql);
	echo "<select name='types' onchange = 'showtext()'>";
	while ($row = mysqli_fetch_array($huoqu, MYSQLI_ASSOC)) {
		if($row['type']!='其他'){
			echo "<option value ='".$row['type']."'>".$row['type']."</option>";
		}
	}
	echo "</select>";
	?>
	</td>
        </tr>
	<tr>
	<td colspan="2">
	文本选择：
	<input type="radio" name="TTM" value="ALL" checked="checked"/>全选&nbsp;&nbsp;&nbsp;
	<input type="radio" name="TTM" value="Term"/>术语&nbsp;&nbsp;&nbsp;
	<input type="radio" name="TTM" value="TMX"/>翻译记忆
	</td>
	</tr>
    </table>
</form>
</body>
</html>